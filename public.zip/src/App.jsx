




import React from "react";
import "animate.css";
import ITIntro from "./Components/ITIntro";
// import Home from "./Component/Home"; // Commented out if individual sections are used

const App = () => {
  return (
    <div>
    
      <ITIntro/>
   
    </div>
  );
};

export default App;
