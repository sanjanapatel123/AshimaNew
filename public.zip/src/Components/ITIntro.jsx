// import React from "react";

// const ITIntro = () => {
//   return (
//     <div className="bg-gradient-to-r from-[#d9e6f5] to-[#bad3ef] min-h-screen flex items-center justify-center font-sans relative overflow-hidden">
//       <div className="max-w-7xl w-full mx-auto px-6 py-16 flex flex-col md:flex-row items-center gap-10">
//         {/* LEFT SIDE TEXT */}
//         <div className="md:w-1/2 z-10">
//           <p className="uppercase text-sm tracking-widest text-gray-600 mb-3">
//             An IT Company Committed To Your Success
//           </p>
//           <h1 className="text-4xl md:text-5xl font-extrabold text-gray-800 mb-6">
//             We Are IT Company
//           </h1>
//           <p className="text-lg text-gray-700 mb-6 leading-relaxed">
//             A driven team of innovators focused on empowering individuals and
//             businesses through smart technology solutions, creative problem
//             solving, and ongoing digital support tailored to your goals.
//           </p>
//           <button className="bg-yellow-400 hover:bg-yellow-500 text-black font-bold px-6 py-3 rounded shadow-md transition duration-300">
//             Contact Us
//           </button>
//         </div>

//         {/* RIGHT SIDE VIDEO */}
//         <div className="md:w-1/2 shadow-xl border border-gray-300 rounded overflow-hidden relative">
//           <iframe
//             className="w-full h-72 md:h-96"
//             src="https://player.vimeo.com/video/665811581?autoplay=1&loop=1&muted=1&background=1"
//             title="IT Office Video"
//             frameBorder="0"
//             allow="autoplay; fullscreen"
//             allowFullScreen
//           ></iframe>
//         </div>
//       </div>

//       {/* LEGO BACKGROUND DECORATION (OPTIONAL) */}
//       <div
//         className="absolute top-0 right-0 w-full h-full opacity-10 z-0"
//         style={{
//           backgroundImage: "url(/your-lego-bg.png)",
//           backgroundSize: "cover",
//           backgroundRepeat: "no-repeat",
//         }}
//       ></div>
//     </div>
//   );
// };

// export default ITIntro;



import React from "react";
import image from "../Images/image.png";

const MilesITIntro = () => {
  return (
    <div
      className="min-h-screen flex items-center justify-center font-sans relative bg-cover bg-center bg-no-repeat"
      style={{ backgroundImage: `url('/bg-lego.jpg')` }} // <-- your background image path
    >
      <div className="bg-gradient-to-r from-[#d9e6f5]/90 to-[#bad3ef]/90 w-full">
        <div className="max-w-7xl mx-auto px-6 py-16 flex flex-col md:flex-row items-center gap-10">
          {/* LEFT TEXT */}
          <div className="md:w-1/2 z-10">
            <p className="uppercase text-sm tracking-widest text-gray-600 mb-3">
              An IT Company Committed To Your Success
            </p>
            <h1 className="text-4xl md:text-5xl font-extrabold text-gray-800 mb-6">
              We Are Miles IT
            </h1>
            <p className="text-lg text-gray-700 mb-6 leading-relaxed">
              A team of tech professionals focused on helping businesses succeed
              through digital strategy, support, and technology implementation.
            </p>
            <button className="bg-yellow-400 hover:bg-yellow-500 text-black font-bold px-6 py-3 rounded shadow-md transition duration-300">
              Contact Us
            </button>
          </div>

          {/* RIGHT VIDEO */}
          <div className="md:w-1/2 shadow-xl border border-gray-300 rounded overflow-hidden">
            <iframe
              className="w-full h-72 md:h-96"
              src="https://player.vimeo.com/video/665811581?autoplay=1&loop=1&muted=1&background=1"
              title="IT Office Video"
              frameBorder="0"
              allow="autoplay; fullscreen"
              allowFullScreen
            ></iframe>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MilesITIntro;
